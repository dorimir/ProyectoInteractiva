# import pandas as pd
from Game.Game import Game

from Game.GameState import GameState
from Mazes.MazeOriginal import MazeOriginal
from Players.QLPlayer import QLPlayer
from Learners.QLearner import QLearner
from Heuristics.HeuristicRafael import HeuristicRafael
import pandas as pd
# from Heuristics.HeuristicCorcella import HeuristicCorcella
# from Heuristics.HeuristicGabrielDist import HeuristicGabrielDist
# from Heuristics.HeuristicIzan import HeuristicIzan


if __name__ == '__main__':
    budget = 1                  # Time, in seconds, that the players have to think
    max_iterations = 100
    verbose = True
    qtable_filename = 'Data/qtable.csv'

    # Set up the game
    maze = MazeOriginal()
    game_state = GameState()
    game_state.reset(maze, max_iterations)

    # First, learn the qtable and save it to a file
    n_episodes = 500

    ##### TABLA Q LEARN #####
    ql = QLearner()
    heuristic = HeuristicRafael()
    ql.set_heuristic(heuristic)
    qtable = ql.learn(game_state, n_episodes)

    df = pd.DataFrame(qtable)
    print(df)
    #####
    ql.write_qtable_to_file(qtable, qtable_filename)
    # Then, play using the information from the qtable
    player = QLPlayer(qtable_filename)
    game = Game()
    game.run(maze, player, budget, max_iterations, verbose)
