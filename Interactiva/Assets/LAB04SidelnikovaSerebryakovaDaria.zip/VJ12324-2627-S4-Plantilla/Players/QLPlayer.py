import pandas as pd
import numpy as np
import random
from Players.Player import Player
from Game.Observation import Observation
from Game.ForwardModel import ForwardModel


class QLPlayer(Player):
    def __init__(self, qt_filename):
        super().__init__()
        self.qtable_filename = qt_filename
        self.previous_position = None

        df = pd.read_csv(self.qtable_filename, header=None)
        self.qtable = df.values

    def reset(self):
        pass

    def get_qtable_filename(self):
        return self.qtable_filename

    def set_qtable_filename(self, qt_filename):
        self.qtable_filename = qt_filename

    #####
    def is_valid_action(self, observation, action):
        current_position = list(observation.get_position())
        fm = ForwardModel()
        test_obs = observation.clone()
        fm.test(test_obs, action)
        new_position = list(test_obs.get_position())

        moved = new_position != current_position
        backwards = (self.previous_position is not None
                     and new_position == list(self.previous_position))
        return moved and not backwards
    #####

    # If it exists, returns a valid action. Otherwise, it returns None
    def get_random_valid_action(self, observation, budget, l_actions):
        current_position = observation.get_position()
        maze_n_cols = observation.get_maze_columns()
        fm = ForwardModel()
        action_found = False
        action = None
        while not action_found and len(l_actions) > 0:
            # Randomly select a new action and test it
            #####
            action = random.choice(l_actions)
            valid_position = self.is_valid_action(observation, action)

            if valid_position:
                action_found = True
            else:
                l_actions.remove(action)
            #####

        if not action_found:
            action = None
        return action

    def think(self, observation, budget):
        l_actions = observation.get_list_actions()
        current_position = observation.get_position()
        maze_n_cols = observation.get_maze_columns()
        idx_state = current_position[0] * maze_n_cols + current_position[1]
        if idx_state < self.qtable.shape[0]:
            # Select the best evaluated action
            #####
            best_action_idx = int(np.argmax(self.qtable[idx_state, :]))
            action = l_actions[best_action_idx]
            #####
            # Test the selected action
            #####
            valid = self.is_valid_action(observation, action)
            if not valid:
                l_actions.remove(action)
                action = self.get_random_valid_action(observation, budget, l_actions)

            if action is not None:
                self.previous_position = list(current_position)
            #####
        else:
            action = None
        return action

    def __str__(self):
        return "QLPlayer"