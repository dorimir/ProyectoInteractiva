﻿import random
from copy import deepcopy
import numpy as np
import pandas as pd
from Game.GameState import GameState
# from Game.Observation import Observation
from Game.ForwardModel import ForwardModel
from Learners.Learner import Learner
from Heuristics.HeuristicRafael import HeuristicRafael

# Agent applying the QLearning algorithm for learning
class QLearner(Learner):
    def __init__(self):
        super().__init__()
        self.qtable = None
        self.alpha = 0.8        # 0 = no aprende nada; 1 = solo importa lo último que pasó
        self.gamma = 0.9        # 0 = solo busca recompensa inmediata
        self.epsilon = 0.1
        self.heuristic = HeuristicRafael()
        self.max_play_steps = 100       #Limite de movimientos
        self.previous_pos = None
        self.qtable_filename = None

    def set_model(self, model):
        self.qtable = deepcopy(model)

    def get_qtable_filename(self):
        return self.qtable_filename

    def set_qtable_filename(self, qt_filename):
        self.qtable_filename = qt_filename

    def set_heuristic(self, heuristic):
        self.heuristic = heuristic

    def adjust_ql_params(self):
        self.alpha -= 0.0006
        self.epsilon += 0.0008

    # TODO: Get a random valid position | PRUEBA SITIOS DISTINTOS PARA VER LOS CAMINOS POSIBLES
    def get_random_valid_position(self, game_state):
        max_attempts = game_state.get_number_states()
        pos_found = False
        random_pos = None  # Actually, a vector, such as [0, 0]

        # Get a random position, with no more attempts than the valid number of positions
        attempts = 0
        while not pos_found and attempts < max_attempts:
            random_row = random.randrange(game_state.get_maze_rows())
            random_col = random.randrange(game_state.get_maze_columns())
            pos_found = not (game_state.is_wall(random_row, random_col)
                             or game_state.maze.is_hole(random_row, random_col)
                             or game_state.maze.is_goal(random_row, random_col))
            attempts += 1
        if pos_found:
            random_pos = [random_row, random_col]
        return random_pos

    # TODO: Get a random valid action, avoiding a backwards move
    def get_random_valid_action(self, obs):
        final_action = None
        actions = obs.get_list_actions()
        test_forward = ForwardModel()
        while final_action is None:
            test_obs = obs.clone()
            action = random.choice(actions)
            test_forward.test(test_obs, action)
            new_pos = test_obs.get_position()
            if new_pos != obs.get_position() and new_pos != self.previous_pos:
                final_action = action
            else:
                actions.remove(action)
                if len(actions) == 0:
                    break
        return final_action

    def get_best_action_state(self, observation, position):
        idx_state = position[0] * observation.get_maze_columns() + position[1]
        action_col = np.argmax(self.qtable[idx_state, :])
        return action_col

    # TODO: Update the qtable, but only when the current and the previous position are different.
    def update_qtable(self, observation, previous_pos, actual_pos, action_idx, reward):
        maze_n_cols = observation.get_maze_columns()
        idx_previous_state = previous_pos[0] * maze_n_cols + previous_pos[1] #Anterior
        idx_actual_state = actual_pos[0] * maze_n_cols + actual_pos[1]  #Actual

        if idx_previous_state != idx_actual_state:
            actual_value = self.qtable[idx_previous_state, action_idx]
            best_future_value = np.max(self.qtable[idx_actual_state, :]) #Mira las rewards de las acciones siguientes
            temporary_difference = reward + self.gamma * best_future_value - actual_value #Expectiva vs Realidad
            new_value = actual_value + self.alpha * temporary_difference #Actualiza + factor sorpresa
            self.qtable[idx_previous_state, action_idx] = new_value #Actualiza experiencia

    # TODO: Apply learning algorithm.
    def learn(self, state: GameState, n_episodes: int):
        # Set an initial qtable as full of zeros
        initial_state = state.clone()
        obs = initial_state.get_observation()
        n_states = initial_state.get_number_states()
        n_actions = obs.get_number_actions()
        self.qtable = np.zeros((n_states, n_actions))

        for episode in range(n_episodes):
            # Reset the game and set the player to the initial position
            initial_state.reset(state.maze, state.max_iterations)

            random_pos = self.get_random_valid_position(initial_state)
            if random_pos is not None:
                initial_state.set_position(random_pos[0], random_pos[1])
            # Play the game
            self.play(initial_state)

            self.adjust_ql_params()
        return self.qtable

    # TODO: Play the game for learning
    def play(self, state: GameState):
        step = 1
        fm = ForwardModel()
        while not state.is_terminal() and step < self.max_play_steps:
            # Get best action to play: explore or exploit
            obs = state.get_observation()
            actual_pos = obs.get_position()
            if random.random() < self.epsilon:
                action_idx = self.get_best_action_state(obs, actual_pos)
                action = obs.get_list_actions()[action_idx]
            else:
                action = self.get_random_valid_action(obs)
                if action is not None:
                    action_idx = action.get_action() - 1

            if action is not None:
                fm.play(state, action)
                reward = self.heuristic.get_score(state.get_observation())
                self.update_qtable(obs, actual_pos, state.get_position(), action_idx, reward)
                self.previous_pos = actual_pos

            step += 1

    @staticmethod
    def write_qtable_to_file(ql_table, filename):
        df = pd.DataFrame(ql_table)
        df.to_csv(filename, index=False, header=False)

    def __str__(self):
        return "QLearner"