class Maze:
    def __init__(self):
        self.number_rows = 0
        self.number_columns = 0

        self.cells = []

    def get_cell(self, row, column):
        return self.cells[row][column]

    def is_empty(self, row, column):
        return self.cells[row][column] == 0

    def is_start(self, row, column):
        return self.cells[row][column] == 1

    def is_hole(self, row, column):
        return self.cells[row][column] == 2

    def is_wall(self, row, column):
        return self.cells[row][column] == 3

    def is_goal(self, row, column):
        return self.cells[row][column] == 4

    def clone(self):
        pass

    def is_into_maze(self, row, column):
        return 0 <= row < self.number_rows and 0 <= column < self.number_columns

    # print maze and set a "*" in the position (row, column)
    def print_maze(self, row, column):
        s = ""
        for i in range(self.number_rows):
            for j in range(self.number_columns):
                if i == row and j == column:
                    s += "*"
                elif self.cells[i][j] == 0:
                    s += "_"
                elif self.cells[i][j] == 1:
                    s += "S"
                elif self.cells[i][j] == 2:
                    s += "X"
                elif self.cells[i][j] == 3:
                    s += "#"
                elif self.cells[i][j] == 4:
                    s += "E"
            s += "\n"
        print(s)

    def get_start_position(self):
        for r in range(self.number_rows):
            for c in range(self.number_columns):
                if self.is_start(r, c):
                    return [r, c]

    def get_goal_position(self):
        for r in range(self.number_rows):
            for c in range(self.number_columns):
                if self.is_goal(r, c):
                    return [r, c]

    def __str__(self):
        return "Maze"
