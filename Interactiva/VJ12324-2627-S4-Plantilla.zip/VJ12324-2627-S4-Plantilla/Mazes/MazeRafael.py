from copy import deepcopy

from Mazes.Maze import Maze


class MazeRafael(Maze):
    def __init__(self):
        super().__init__()
        self.number_rows = 8
        self.number_columns = 8

        self.cells = [[1, 0, 0, 2, 0, 0, 0, 0],
                      [3, 3, 0, 3, 0, 0, 0, 0],
                      [2, 0, 0, 3, 0, 0, 0, 0],
                      [2, 0, 2, 2, 2, 3, 3, 0],
                      [3, 0, 0, 3, 0, 0, 0, 2],
                      [0, 3, 0, 0, 0, 3, 0, 2],
                      [0, 0, 2, 2, 3, 3, 0, 2],
                      [0, 0, 0, 0, 0, 2, 0, 4]]

    def clone(self):
        new_maze = MazeRafael()
        new_maze.number_rows = self.number_rows
        new_maze.number_columns = self.number_columns
        new_maze.cells = deepcopy(self.cells)
        return new_maze

    def __str__(self):
        return "MazeRafael "

