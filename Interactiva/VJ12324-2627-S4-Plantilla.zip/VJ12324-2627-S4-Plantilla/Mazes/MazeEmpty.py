from copy import deepcopy

from Mazes.Maze import Maze


class MazeEmpty(Maze):
    def __init__(self):
        super().__init__()
        self.number_rows = 9
        self.number_columns = 9

        self.cells = [[1, 0, 0, 0, 0, 0, 0, 0, 0],
                      [0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [0, 0, 0, 0, 0, 0, 0, 0, 4]]

    def clone(self):
        new_maze = MazeEmpty()
        new_maze.number_rows = self.number_rows
        new_maze.number_columns = self.number_columns
        new_maze.cells = deepcopy(self.cells)
        return new_maze

    def __str__(self):
        return "MazeEmpty    "
