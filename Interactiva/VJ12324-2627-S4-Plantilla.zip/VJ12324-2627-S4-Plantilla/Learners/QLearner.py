import random
from copy import deepcopy
import numpy as np
import pandas as pd
from Game.GameState import GameState
# from Game.Observation import Observation
from Game.ForwardModel import ForwardModel
from Learners.Learner import Learner
from Heuristics.HeuristicDistance import HeuristicDistance


# Agent applying the QLearning algorithm for learning
class QLearner(Learner):
    def __init__(self):
        super().__init__()
        self.qtable = None
        self.alpha = 0.8
        self.gamma = 0.9
        self.epsilon = 0.1
        self.heuristic = HeuristicDistance()
        self.max_play_steps = 100
        self.previous_pos = None
        self.qtable_filename = None

    # Set the qtable with a previous calculated one
    def set_model(self, model):
        self.qtable = deepcopy(model)

    def get_qtable_filename(self):
        return self.qtable_filename

    def set_qtable_filename(self, qt_filename):
        self.qtable_filename = qt_filename

    # Set the heuristic
    def set_heuristic(self, heuristic):
        self.heuristic = heuristic

    def adjust_ql_params(self):
        self.alpha -= 0.0006
        self.epsilon += 0.0008

    # TODO: Get a random valid position
    def get_random_valid_position(self, game_state):
        # Estimate the maximum number of valid positions
        pos_found = False
        random_pos = None # Actually, a vector, such as [0, 0]

        # Get a random position, with no more attempts than the valid number of positions
        if pos_found:
            random_pos = [random_row, random_col]
        return random_pos

    # TODO: Get a random valid action, avoiding a backwards move
    def get_random_valid_action(self, obs):
        final_action = None
        actions = obs.get_list_actions()
        test_forward = ForwardModel()
        while final_action is None:
            test_obs = obs.clone()
            #...
        return final_action

    # Use the qtable to find the best action given the current state.
    def get_best_action_state(self, observation, position):
        idx_state = position[0] * observation.get_maze_columns() + position[1]
        action_col = np.argmax(self.qtable[idx_state, :])
        return action_col

    # TODO: Update the qtable, but only when the current and the previous position are different.
    def update_qtable(self, observation, previous_pos, actual_pos, action_idx, reward):
        maze_n_cols = observation.get_maze_columns()
        idx_previous_state = previous_pos[0] * maze_n_cols + previous_pos[1]
        idx_actual_state = actual_pos[0] * maze_n_cols + actual_pos[1]

        if idx_previous_state != idx_actual_state:
            # actual_value = ...
            # best_future_value = ...
            # temporary_difference = ...
            # new_value = ...
            # self.qtable[idx_previous_state, action_idx] = ...

    # TODO: Apply learning algorithm.
    def learn(self, state: GameState, n_episodes: int):
        # Set an initial qtable as full of zeros
        initial_state = state.clone()
        obs = initial_state.get_observation()
        n_states = initial_state.get_number_states()
        n_actions = obs.get_number_actions()
        self.qtable = np.zeros((n_states, n_actions))
        
        # Learn the qtable by playing the game a given number of times (n_episodes)
        for episode in range(n_episodes):
            # Reset the game and set the player to the initial position
            initial_state.reset(state.maze, state.max_iterations)

            # Set a new random initial position
            # Play the game
            # Adjust QLearning parameters for the next episode
        return self.qtable

    # TODO: Play the game for learning
    def play(self, state: GameState):
        step = 1
        fm = ForwardModel()
        while not state.is_terminal() and step < self.max_play_steps:
            # Get best action to play: explore or exploit

            # If it is not null, apply the action

            step += 1

    @staticmethod
    def write_qtable_to_file(ql_table, filename):
        df = pd.DataFrame(ql_table)
        df.to_csv(filename, index=False, header=False)

    def __str__(self):
        return "QLearner"
