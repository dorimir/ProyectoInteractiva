# Abstract class for learners
class Learner:
    def __init__(self):
        pass

    def learn(self, state, n_episodes):
        pass

    def set_heuristic(self, heuristic):
        pass

    def __str__(self):
        pass
