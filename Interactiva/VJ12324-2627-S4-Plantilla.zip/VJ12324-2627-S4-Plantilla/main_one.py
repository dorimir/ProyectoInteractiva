from Game.Game import Game
from Game.GameState import GameState
from Mazes.MazeOriginal import MazeOriginal
# from Mazes.MazeMontoliu import MazeMontoliu
# from Players.OSLAPlayer import OSLAPlayer
# from Players.RandomPlayer import RandomPlayer
# from Players.SimpleRulePlayer import SimpleRulePlayer
# from Players.MCTSPlayer import MCTSPlayer
from Heuristics.HeuristicDistanceInv import HeuristicDistanceInv
from Players.QLPlayer import QLPlayer
from Learners.QLearner import QLearner


if __name__ == '__main__':
    budget = 1                  # Time, in seconds, that the players have to think
    max_iterations = 100
    verbose = True

    qtable_filename = 'Data/qtable.csv'

    # Set up the game
    maze = MazeOriginal()
    game_state = GameState()
    game_state.reset(maze, max_iterations)
    # maze = MazeOriginal()
    # maze = MazeEmpty()
    # maze = MazeSimple()
    # maze = MazeAlmagro()
    # maze = MazeFuster()
    # maze = MazeGarciaL()
    # maze = MazeGarciaS()
    # maze = MazeGomez()
    # maze = MazeGonzalez()
    # maze = MazeHuguet()
    # maze = MazeIzan()
    # maze = MazeIzquierdo()
    # maze = MazeLopez()
    # maze = MazeMartinez()
    # maze = MazeMontoliu()
    # maze = MazeOriginal()
    # maze = MazeRafael()
    # maze = MazeSanchez()
    # maze = MazeSergio()
    # maze = MazeToro()
    # maze = MazeTrigueros()
    # maze = MazeVictor()
    # maze = MazeYeray()


    # player = RandomPlayer()
    # player = SimpleRulePlayer()
    # player = OSLAPlayer()
    # player = MCTSPlayer()

    # In the case of QLearning, first, learn the qtable and save it to a file
    n_episodes = 100
    ql = QLearner()
    heuristic = HeuristicDistanceInv()
    ql.set_heuristic(heuristic)
    qtable = ql.learn(game_state, n_episodes)
    ql.write_qtable_to_file(qtable, qtable_filename)

    # Then, play using the information from the qtable
    player = QLPlayer(qtable_filename)
    game = Game()
    game.run(maze, player, budget, max_iterations, verbose)


