import csv
from timeit import default_timer as timer
from Game.Game import Game
from Game.GameState import GameState
from Mazes.MazeEmpty import MazeEmpty
from Mazes.MazeSimple import MazeSimple
from Mazes.MazeAlmagro import MazeAlmagro
from Mazes.MazeFuster import MazeFuster
from Mazes.MazeGarciaL import MazeGarciaL
from Mazes.MazeGarciaS import MazeGarciaS
from Mazes.MazeGomez import MazeGomez
from Mazes.MazeGonzalez import MazeGonzalez
from Mazes.MazeHuguet import MazeHuguet
from Mazes.MazeIzan import MazeIzan
from Mazes.MazeIzquierdo import MazeIzquierdo
from Mazes.MazeLopez import MazeLopez
from Mazes.MazeMartinez import MazeMartinez
from Mazes.MazeMontoliu import MazeMontoliu
from Mazes.MazeOriginal import MazeOriginal
from Mazes.MazeRafael import MazeRafael
from Mazes.MazeSanchez import MazeSanchez
from Mazes.MazeSergio import MazeSergio
from Mazes.MazeSimple import MazeSimple
from Mazes.MazeToro import MazeToro
from Mazes.MazeTrigueros import MazeTrigueros
from Mazes.MazeVictor import MazeVictor
from Mazes.MazeYeray import MazeYeray
from Players.OSLAPlayer import OSLAPlayer
from Players.RandomPlayer import RandomPlayer
from Players.SimpleRulePlayer import SimpleRulePlayer
from Players.GoodRulePlayer import GoodRulePlayer
from Players.MCTSPlayer import MCTSPlayer
from Learners.QLearner import QLearner
from Players.QLPlayer import QLPlayer
from Heuristics.HeuristicDistance import HeuristicDistance
# from Heuristics.HeuristicCorcella import HeuristicCorcella
# from Heuristics.HeuristicDistanceInv import HeuristicDistanceInv
# from Heuristics.HeuristicGabrielDist import HeuristicGabrielDist
# from Heuristics.HeuristicIzan import HeuristicIzan
# from Heuristics.HeuristicMonar import HeuristicMonar
# from Heuristics.HeuristicMonrabal import HeuristicMonrabal
# from Heuristics.HeuristicRafael import HeuristicRafael
# from Heuristics.HeuristicSanchez import HeuristicSanchez
# from Heuristics.HeuristicSegrelles import HeuristicSegrelles
# from Heuristics.HeuristicVictor import HeuristicVictor
# from Heuristics.HeuristicTeray import HeuristicYeray
from Heuristics.SimpleHeuristic import SimpleHeuristic





# test just one player and one maze
def test_just_one(maze, player, budget, max_iterations, verbose):
    # Set up the game. This should go in one of the functions above
    game = Game()
    game_state = GameState()
    game_state.reset(maze, max_iterations)

    # Then, in the case of the QLPlayer, learn the qtable for
    # Q-Learning and save it to a file
    if str(player)=="QLPlayer":
        n_episodes = 1000
        ql = QLearner()
        heuristic = SimpleHeuristic() # HeuristicDistance()
        ql.set_heuristic(heuristic)
        qtable = ql.learn(game_state, n_episodes)
        qtable_filename = ql.get_qtable_filename()
        ql.write_qtable_to_file(qtable, qtable_filename)

    # Finally, run the game
    result = game.run(maze, player, budget, max_iterations, verbose)
    return result


# test all players and all mazes
def test_all_players_and_mazes(l_players, l_mazes, budget, max_iterations, verbose):
    points = [0]*len(l_players)

    with open("Data/PlayerDataGabriel_20231010_1.csv", 'w', encoding='UTF8', newline='') as player_file:
        writer = csv.writer(player_file)
        writer.writerow(["Player", "Player_Config", "Maze", "Result", "Iterations", "Time"])
        for player in l_players:
            for maze in l_mazes:
                player.reset()  # reset player (It is important)
                start_time = timer()
                [reached_goal, iterations_needed] = test_just_one(maze, player, budget, max_iterations, verbose)
                end_time = timer()
                if reached_goal:
                    points[l_players.index(player)] += 1
                    result = "WIN"
                else:
                    result = "LOSE"
                print("Player: " + str(player) + " Player config: " + str(player.config_info_str()) +
                      " Maze: " + str(maze) +
                      " Result: " + result + "  Iter: " + str(iterations_needed) +
                      " Time: " + str.format("{0:5f}", end_time - start_time))
                writer.writerow([str(player), str(player.config_info_str()), str(maze),
                                 result, str(iterations_needed),
                                 str.format("{0:5f}", end_time - start_time)])
            print("--- ")

    print("-----------------------------------------------------")
    for player in l_players:
        print("Player: " + str(player) + " Points: " + str(points[l_players.index(player)]))


# -----------------------
#     main program
# -----------------------
if __name__ == '__main__':
    budget = 1            # Time, in seconds, that the players have to think
    max_iterations = 200  # Maximum number of iterations
    verbose = False       # True: print the maze at each iteration
    qtable_filename = 'Data/qtable_one_ql_20231010_1.csv'

    # Set up the game. This should go in one of the functions above
    # maze = MazeOriginal()
    # game_state = GameState()
    # game_state.reset(maze, max_iterations)

    # Then, learn the qtable for Q-Learning and save it to a file
    # n_episodes = 100
    # ql = QLearner()
    # heuristic = DistanceHeuristic()
    # ql.set_heuristic(heuristic)
    # qtable = ql.learn(game_state, n_episodes)
    # ql.write_qtable_to_file(qtable, qtable_filename)


    l_players = [# RandomPlayer(), SimpleRulePlayer(), OSLAPlayer(),
                 # GoodRulePlayer(), # MCTSPlayer(),
                 QLPlayer(qtable_filename)]

    l_mazes = [MazeOriginal(), MazeEmpty(), MazeSimple(),
               MazeAlmagro(), MazeFuster(), MazeGarciaL(), MazeGarciaS(),
               MazeGomez(), MazeGonzalez(), MazeHuguet(), MazeIzan(), MazeIzquierdo(),
               MazeLopez(), MazeMartinez(), MazeMontoliu(), MazeOriginal(), MazeRafael(),
               MazeSanchez(), MazeSergio(), MazeToro(), MazeTrigueros(), MazeVictor(),
               MazeYeray()]

    test_all_players_and_mazes(l_players, l_mazes, budget, max_iterations, verbose)
