from Heuristics.Heuristic import Heuristic


class HeuristicVictor(Heuristic):
    def __init__(self):
        super().__init__()

    def get_score(self, observation):
        if observation.is_in_a_hole():
            return -1000
        elif observation.reached_goal():
            return 1000
        elif observation.is_wall():
            return -500
        elif not observation.is_into_maze():
            return -500
        else:
            return 0
