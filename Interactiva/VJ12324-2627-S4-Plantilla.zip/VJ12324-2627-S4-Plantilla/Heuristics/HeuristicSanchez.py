from Heuristics.Heuristic import Heuristic


class HeuristicSanchez(Heuristic):
    def __init__(self):
        super().__init__()
        self.last_position = None

    def get_score(self, observation):
        current_position = observation.get_position()
        row, column = current_position

        if observation.is_in_a_hole():
            return -1000
        elif observation.reached_goal():
            return 1000
        elif observation.is_wall(row,column):
            return -1000
        elif not observation.is_into_maze(row,column):
            return -1000
        else:
            return 1000
