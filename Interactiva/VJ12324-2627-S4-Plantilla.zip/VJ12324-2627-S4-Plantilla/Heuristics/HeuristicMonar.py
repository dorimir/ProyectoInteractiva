from Heuristics.Heuristic import Heuristic
import math


class HeuristicMonar(Heuristic):
    def __init__(self):
        super().__init__()

    def get_score(self, observation):
        if observation.is_in_a_hole():
            return -1000
        elif observation.reached_goal():
            return 1000
        elif not observation.is_wall(observation.row, observation.column):
            # Puntuación igual a la distancia de la posición rspecto al inicio del laberinto
            return math.sqrt((observation.get_position()[0]-observation.get_start_position()[0])**2
                             + (observation.get_position()[1]-observation.get_start_position()[1])**2)
        else:
            return 0
