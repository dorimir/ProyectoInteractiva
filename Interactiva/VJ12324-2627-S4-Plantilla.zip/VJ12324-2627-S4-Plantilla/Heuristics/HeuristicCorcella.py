from Heuristics.Heuristic import Heuristic


class HeuristicCorcella(Heuristic):
    def __init__(self):
        super().__init__()

    def heuristic(self, observation, action):
        [row, column] = observation.get_position()
        [row_distance_goal, col_distance_goal] = observation.get_distance_goal(row, column)

        if action.is_up() and observation.is_into_maze(row - 1, column) and not observation.is_wall(row - 1, column) and not observation.is_hole(row - 1, column):
            previous_position = observation.get_position()
            observation.set_position(row - 1, column)
            [new_row_dist_goal, new_col_dist_goal] = observation.get_distance_goal(row - 1, column)
            if previous_position == observation.get_position():
                return 0
            if row_distance_goal < 0:
                if new_row_dist_goal > row_distance_goal:
                    return 2
                else:
                    return 1
            else:
                if new_row_dist_goal < row_distance_goal:
                    return 2
                else:
                    return 1

        elif action.is_right() and observation.is_into_maze(row, column + 1) and not observation.is_wall(row, column + 1) and not observation.is_hole(row, column + 1):
            previous_position = observation.get_position()
            observation.set_position(row, column + 1)
            [new_row_dist_goal, new_col_dist_goal] = observation.get_distance_goal(row, column + 1)
            if previous_position == observation.get_position():
                return 0
            if col_distance_goal < 0:
                if new_col_dist_goal > col_distance_goal:
                    return 2
                else:
                    return 1
            else:
                if new_col_dist_goal < col_distance_goal:
                    return 2
                else:
                    return 1

        elif action.is_down() and observation.is_into_maze(row + 1, column) and not observation.is_wall(row + 1, column) and not observation.is_hole(row + 1, column):
            previous_position = observation.get_position()
            observation.set_position(row + 1, column)
            [new_row_dist_goal, new_col_dist_goal] = observation.get_distance_goal(row + 1, column)
            if previous_position == observation.get_position():
                return 0
            if row_distance_goal < 0:
                if new_row_dist_goal > row_distance_goal:
                    return 2
                else:
                    return 1
            else:
                if new_row_dist_goal < row_distance_goal:
                    return 2
                else:
                    return 1

        elif action.is_left() and observation.is_into_maze(row, column - 1) and not observation.is_wall(row, column - 1) and not observation.is_hole(row, column - 1):
            previous_position = observation.get_position()
            observation.set_position(row, column - 1)
            [new_row_dist_goal, new_col_dist_goal] = observation.get_distance_goal(row, column - 1)
            if previous_position == observation.get_position():
                return 0
            if col_distance_goal < 0:
                if new_col_dist_goal > col_distance_goal:
                    return 2
                else:
                    return 1
            else:
                if new_col_dist_goal < col_distance_goal:
                    return 2
                else:
                    return 1
        else:
            return 0
