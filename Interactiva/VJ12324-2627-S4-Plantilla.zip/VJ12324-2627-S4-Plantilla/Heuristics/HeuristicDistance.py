import math

from Heuristics.Heuristic import Heuristic


class HeuristicDistance(Heuristic):
    def __init__(self):
        super().__init__()

    def get_score(self, observation):
        if observation.is_in_a_hole():
            return -1000

        if observation.reached_goal():
            return 1000

        goal_position = observation.get_goal_position()
        actual_position = observation.get_position()
        distance = math.sqrt(
            (goal_position[0] - actual_position[0]) ** 2 + (goal_position[1] - actual_position[1]) ** 2)

        if distance < 3:
            return 750 - distance

        if distance < 5:
            return 500 - distance

        if distance < 7:
            return 250 - distance

        return 100 - distance

    def __str__(self):
        return "Distance"
