from Heuristics.Heuristic import Heuristic
import math


class HeuristicSegrelles(Heuristic):
    def __init__(self):
        super().__init__()

    def __str__(self):
        return "Advanced Heuristic"

    def get_score(self, observation):
        if observation.is_in_a_hole():
            return -1000
        elif observation.reached_goal():
            return 1000
        else:
            return math.sqrt(
                math.pow(observation.get_start_position()[0] - observation.get_position()[0], 2) + math.pow(
                    observation.get_start_position()[1] - observation.get_position()[1], 2))
