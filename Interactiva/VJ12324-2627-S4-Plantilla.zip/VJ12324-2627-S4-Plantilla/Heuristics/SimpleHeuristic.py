from Heuristics.Heuristic import Heuristic


class SimpleHeuristic(Heuristic):
    def __init__(self):
        super().__init__()

    def get_score(self, observation):
        if observation.is_in_a_hole():
            return -1000
        elif observation.reached_goal():
            return 1000
        else:
            return 0

    def __str__(self):
        return "SimpleHeuristic"
