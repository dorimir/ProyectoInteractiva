from Heuristics.Heuristic import Heuristic
import math

class HeuristicGabrielDist(Heuristic):
    def __init__(self):
        super().__init__()

    def get_score(self, observation):
        if observation.is_in_a_hole():
            return -1000
        elif observation.reached_goal():
            return 1000
        else:
            start_position = observation.get_start_position()
            current_position = observation.get_position()
            return math.dist(start_position, current_position)

    def __str__(self):
        return "HeuristicGabrielDist"
