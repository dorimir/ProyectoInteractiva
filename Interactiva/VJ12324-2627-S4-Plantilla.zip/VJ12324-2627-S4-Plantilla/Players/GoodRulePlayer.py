from Game.ForwardModel import ForwardModel
from Players.Player import Player


class GoodRulePlayer(Player):
    def __init__(self):
        super().__init__()
        self.first_action = None
        self.positions_played = None
        self.actions_played = None
        self.forward_model = ForwardModel()

    def reset(self):
        self.actions_played = []
        self.positions_played = []
        self.first_action = True

    def think(self, observation, budget):
        if self.first_action:
            self.first_action = False
            self.actions_played = []
            self.positions_played.append(observation.get_start_position())  # add start position

        list_actions = observation.get_list_actions()

        for action in list_actions:
            obs = observation.clone()

            current_position = observation.get_position()  # position before testing the action
            self.forward_model.test(obs, action)
            new_position = obs.get_position()              # position after testing the action

            if obs.reached_goal() or \
                    (not obs.is_in_a_hole() and
                     new_position != current_position and
                     new_position not in self.positions_played):
                self.actions_played.append(action)
                self.positions_played.append(new_position)
                return action

        # if reached here, no action was selected (the player is blocked)
        selected_action = self.actions_played.pop()
        selected_action.reverse_action()
        return selected_action

    def config_info_str(self):
        return "None"

    def __str__(self):
        return "GoodRulePlayer"
