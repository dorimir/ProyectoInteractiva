import pandas as pd
import numpy as np
import random
from Players.Player import Player
from Game.Observation import Observation
from Game.ForwardModel import ForwardModel


class QLPlayer(Player):
    def __init__(self, qt_filename):
        super().__init__()
        self.qtable_filename = qt_filename
        self.previous_position = None

        df = pd.read_csv(self.qtable_filename, header=None)
        self.qtable = df.values

    def reset(self):
        pass

    def get_qtable_filename(self):
        return self.qtable_filename

    def set_qtable_filename(self, qt_filename):
        self.qtable_filename = qt_filename

    # TODO: If it exists, returns a valid action. Otherwise, it returns None
    def get_random_valid_action(self, observation, budget, l_actions):
        current_position = observation.get_position()
        maze_n_cols = observation.get_maze_columns()
        fm = ForwardModel()
        action_found = False
        action = None
        while not action_found and len(l_actions) > 0:
            # Randomly select a new action and test it

            # If the new action is not valid, if possible, select a new one at random
            valid_position = False

        if not action_found:
            action = None
        return action

    def think(self, observation, budget):
        l_actions = observation.get_list_actions()
        current_position = observation.get_position()
        maze_n_cols = observation.get_maze_columns()
        idx_state = current_position[0] * maze_n_cols + current_position[1]
        if idx_state < self.qtable.shape[0]:
            # Select the best evaluated action

            # Test the selected action

            # If the action is not valid, discard it and, if possible, select another one at
            # If the action is valid, the current position becomes the previous one

        else:
            action = None
        return action

    def __str__(self):
        return "QLPlayer"
