import random

from Players.Player import Player


class RandomPlayer(Player):
    # Randomly selects one action from the list of possible actions
    def think(self, observation, budget):
        list_actions = observation.get_list_actions()  # list of actions that can be played
        return random.choice(list_actions)             # get one randomly

    def config_info_str(self):
        return "None"

    def __str__(self):
        return "RandomPlayer"
