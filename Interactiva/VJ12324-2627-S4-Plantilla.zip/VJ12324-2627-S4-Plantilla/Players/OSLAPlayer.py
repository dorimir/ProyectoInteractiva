import math

from Game.ForwardModel import ForwardModel
from Heuristics.SimpleHeuristic import SimpleHeuristic
from Players.Player import Player


class OSLAPlayer(Player):
    def __init__(self):
        super().__init__()
        self.forward_model = ForwardModel()
        self.heuristic = SimpleHeuristic()

    def reset(self):
        pass

    def think(self, observation, budget):
        # TO DO
        # Get the list of all possible actions

        # For each action,
        # test it on a clone of the observation
        # and use the heuristic to evaluate it.
        # Get the action with the best evaluation.
        # Discard actions that the player fall into a hole,
        # move backwards, or not move at all.
        best_score = -math.inf
        best_action = None
        #for action in list_actions:
            # Do something here

        return best_action

    def __str__(self):
        return "OSLAPlayer"
