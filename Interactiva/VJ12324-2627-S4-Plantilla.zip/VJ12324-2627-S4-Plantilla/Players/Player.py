# Abstract class for players
class Player:
    def __init__(self):
        pass

    def think(self, observation, budget):
        pass

    def reset(self):
        pass

    def config_info_str(self):
        pass

    def __str__(self):
        pass
