import math
import random

from Game.ForwardModel import ForwardModel
from Heuristics.SimpleHeuristic import SimpleHeuristic
from Players.Player import Player


class MCTSNode:
    def __init__(self, action, parent, observation):
        self.action = action  # the move that got us to this node - "None" for the root node
        self.parent = parent  # "None" for the root node
        self.children = []
        self.wins = 0
        self.visits = 0
        self.observation = observation
        self.big_number = 100000

    def get_ucb(self):
        if self.visits == 0:
            return self.big_number + random.random()
        else:
            return self.wins / self.visits + math.sqrt(2 * math.log(self.parent.visits) / self.visits)

    def get_best_child(self):
        best_child = None
        best_ucb = -self.big_number
        for child in self.children:
            ucb = child.get_ucb()
            if ucb > best_ucb:
                best_child = child
                best_ucb = ucb
        return best_child

    def add_child(self, action, observation):
        new_node = MCTSNode(action, self, observation)
        self.children.append(new_node)
        return new_node

    def update(self, result):
        self.visits += 1
        self.wins += result

    def is_leaf(self):
        return len(self.children) == 0

    def has_been_visited(self):
        return self.visits > 0

    def has_parent(self):
        return self.parent is not None

    def get_observation(self):
        return self.observation


class MCTSPlayer(Player):
    def __init__(self):
        super().__init__()
        self.forward_model = ForwardModel()
        self.heuristic = SimpleHeuristic()

    def reset(self):
        pass

    def think(self, observation, budget):
        root_node = MCTSNode(None, None, observation)

        # Fill with children of the root node
        self.expand_node(root_node)

        iteration = 1
        iter_max = 10000

        # TO DO
        # 1) This loop is unnecessarily inefficient.
        # It may keep iterating when it is clear that
        # the player has won or lost.
        # 2) Review the implementation of the MCTS
        # algorithm in this method. Is it correct?
        game_over = False
        while iteration < iter_max and not game_over:
            current = root_node

            # Traverse the tree until a leaf node is reached
            while not current.is_leaf():
                current = current.get_best_child()

            if not current.has_been_visited():
                # Rollout from this node and backpropagate (update the score of all the nodes in the path)
                score = self.rollout(current)
                self.backpropagate(current, score)
            else:
                # Expand the node
                self.expand_node(current)
            game_over = current.observation.is_terminal()
            iteration += 1

        # get child with best score
        best_child = root_node.get_best_child()
        return best_child.action

    # Expand the current node with all the possible actions from the current state
    # TO DO: Get all possible actions and expand the current node with the effect
    # of each of them
    def expand_node(self, node):
        # Get the list of all possible actions from an observation of 'node'
        # list_possible_actions = ...

        # Expand using each possible action
        for action in list_possible_actions:
            # Clone the observation of the current node and use the
            # forward model to test the action on that observation.
            # Remember to get the position before (previous_position)
            # and after (actual_position) testing the action.
            # new_observation = ...
            # previous_position = ...
            # self.forward_model.test(...)
            # actual_position = ...

            # If the action produces a change in the current position, and
            # it doesn't cause falling into a hole, add that action and observation clone
            # as a child of the current node
            if previous_position != actual_position and not new_observation.is_in_a_hole():
                node.add_child(action, new_observation)

    # TO DO: Simulate until a terminal state is reached.
    # Then, the score of the last state is returned.
    def rollout(self, node):
        # Consider a limit in the depth of this branch, that is,
        # in the  number of nodes to be produced.
        max_iterations = 10

        # Get a clone of an observation of the current node as starting point
        # new_observation = ...

        # Go producing nodes until a terminal node or the maximum number of
        # iterations is reached
        iterations = 1
        while # ... :
            # From the list of possible actions, pick up one at random
            # l_possible_actions = ...
            # action = ...

            # Use the forward model to test it on the cloned observation
            # self.forward_model.test(...)
            iterations += 1

        # Return the score of the last observation
        return self.heuristic.get_score(new_observation)

    # Update the score of all the nodes in the path
    def backpropagate(self, node, score):
        # TO DO: Go up through the node hierarchy to update the score of each node
        # in the branch
        while node is not None:
            # Update current node's score
            # node.update(...)

            # Go up to the parent of the current node
            node = node.parent

    def __str__(self):
        return "MCTSPlayer"
