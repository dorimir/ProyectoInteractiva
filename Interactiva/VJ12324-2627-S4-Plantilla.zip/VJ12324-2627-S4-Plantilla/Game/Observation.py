from Game.Action import Action


class Observation:
    def __init__(self):
        self.row = 0
        self.column = 0
        self.maze = None
        self.iteration_number = 0
        self.max_iterations = 0

    def set(self, game_state):
        self.row = game_state.row
        self.column = game_state.column
        self.maze = game_state.maze.clone()
        self.iteration_number = game_state.iteration_number
        self.max_iterations = game_state.max_iterations

    def get_position(self):
        return [self.row, self.column]

    def get_maze_columns(self):
        return self.maze.number_columns

    def get_maze_rows(self):
        return self.maze.number_rows

    def set_position(self, row, column):
        self.row = row
        self.column = column

    # Deep copy of the object
    def clone(self):
        new_observation = Observation()
        new_observation.row = self.row
        new_observation.column = self.column
        new_observation.maze = self.maze.clone()
        new_observation.iteration_number = self.iteration_number
        new_observation.max_iterations = self.max_iterations
        return new_observation

    # Returns the list of valid action given the actual state of the game.
    # In this case, the four actions are always returned.
    def get_list_actions(self):
        a_up = Action()
        a_right = Action()
        a_down = Action()
        a_left = Action()

        a_up.set_up()
        a_right.set_right()
        a_down.set_down()
        a_left.set_left()

        return [a_up, a_right, a_down, a_left]

    # Returns the number of valid actions
    def get_number_actions(self):
        return len(self.get_list_actions())

    def print_maze(self):
        self.maze.print_maze(self.row, self.column)

    # Returns True if the player has reached the goal cell. False Otherwise.
    def reached_goal(self):
        return self.maze.is_goal(self.row, self.column)

    def is_in_a_hole(self):
        return self.maze.is_hole(self.row, self.column)

    # Returns True if the position is a wall. False Otherwise.
    def is_wall(self, row, column):
        return self.maze.is_wall(row, column)

    # Returns True if the position is a valid cell in the maze. False Otherwise.
    def is_into_maze(self, row, column):
        return self.maze.is_into_maze(row, column)

    def get_start_position(self):
        return self.maze.get_start_position()

    def get_goal_position(self):
        return self.maze.get_goal_position()

    def is_terminal(self):
        return self.maze.is_goal(self.row, self.column) or \
               self.maze.is_hole(self.row, self.column) or \
               self.iteration_number >= self.max_iterations

    def __str__(self):
        s = "Position: [" + str(self.row) + ", " + str(self.column) + "]\n"
        s += str(self.maze)
        return s

