class Action:
    def __init__(self):
        self.action = 0

    def get_action(self):
        return self.action

    def is_up(self):
        return self.action == 1

    def is_right(self):
        return self.action == 2

    def is_down(self):
        return self.action == 3

    def is_left(self):
        return self.action == 4

    def set_up(self):
        self.action = 1

    def set_right(self):
        self.action = 2

    def set_down(self):
        self.action = 3

    def set_left(self):
        self.action = 4

    def reverse_action(self):
        if self.action == 1:
            self.action = 3
        elif self.action == 2:
            self.action = 4
        elif self.action == 3:
            self.action = 1
        elif self.action == 4:
            self.action = 2

    def __str__(self):
        s = ""
        if self.action == 1:
            s += "UP"
        elif self.action == 2:
            s += "RIGHT"
        elif self.action == 3:
            s += "DOWN"
        elif self.action == 4:
            s += "LEFT"
        return s
