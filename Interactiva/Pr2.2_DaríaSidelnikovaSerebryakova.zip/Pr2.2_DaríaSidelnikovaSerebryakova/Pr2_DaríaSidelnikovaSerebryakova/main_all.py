from Game.Game import Game
from Mazes.MazeAlmagro import MazeAlmagro
from Mazes.MazeFuster import MazeFuster
from Mazes.MazeGarciaL import MazeGarciaL
from Mazes.MazeGarciaS import MazeGarciaS
from Mazes.MazeGomez import MazeGomez
from Mazes.MazeGonzalez import MazeGonzalez
from Mazes.MazeIzquierdo import MazeIzquierdo
from Mazes.MazeLopez import MazeLopez
from Mazes.MazeMartinez import MazeMartinez
from Mazes.MazeMontoliu import MazeMontoliu
from Mazes.MazeOriginal import MazeOriginal
from Mazes.MazeSanchez import MazeSanchez
from Mazes.MazeTrigueros import MazeTrigueros
from Players.OSLAPlayer import OSLAPlayer
from Players.RandomPlayer import RandomPlayer
from Players.SimpleRulePlayer import SimpleRulePlayer


# test just one player and one maze
def test_just_one(maze, player, budget, max_iterations, verbose):
    game = Game()
    result = game.run(maze, player, budget, max_iterations, verbose)
    return result


# test all players and all mazes
def test_all_players_and_mazes(l_players, l_mazes, budget, max_iterations, verbose):
    points = [0]*len(l_players)
    for player in l_players:
        for maze in l_mazes:
            player.reset()  # reset player (It is important)
            [reached_goal, iterations_needed] = test_just_one(maze, player, budget, max_iterations, verbose)
            if reached_goal:
                points[l_players.index(player)] += 1
                print("Player: " + str(player) + " Maze: " + str(maze) + " WIN  Iter = " + str(iterations_needed))
            else:
                print("Player: " + str(player) + " Maze: " + str(maze) + " LOSE Iter = " + str(iterations_needed))
        print("--- ")

    print("-----------------------------------------------------")
    for player in l_players:
        print("Player: " + str(player) + " Points: " + str(points[l_players.index(player)]))

    # TO DO: Store the above results in a file with the following fields:
    # player, maze, win_or_lose, number_of_iterations

# -----------------------
#     main program
# -----------------------
if __name__ == '__main__':
    budget = 1            # Time, in seconds, that the players have to think
    max_iterations = 100  # Maximum number of iterations
    verbose = True       # True: print the maze at each iteration

    l_players = [RandomPlayer(), SimpleRulePlayer(), OSLAPlayer()]

    l_mazes = [MazeOriginal(), MazeAlmagro(), MazeFuster(), MazeGarciaL(), MazeGarciaS(),
               MazeGomez(), MazeGonzalez(), MazeIzquierdo(), MazeLopez(), MazeMartinez(),
               MazeMontoliu(), MazeOriginal(), MazeSanchez(), MazeTrigueros()]

    test_all_players_and_mazes(l_players, l_mazes, budget, max_iterations, verbose)


