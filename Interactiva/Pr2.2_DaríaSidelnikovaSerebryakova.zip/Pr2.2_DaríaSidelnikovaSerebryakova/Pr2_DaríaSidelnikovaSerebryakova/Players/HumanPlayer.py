from Players.Player import Player


class HumanPlayer(Player):
    # There is a text-based GUI to select the action to be played
    def think(self, observation, budget):
        list_actions = observation.get_list_actions()         # actions that can be played
        i = 0
        for action in list_actions:
            print("Action: " + str(i) + " -> " + str(action))
            i += 1

        # player must select a number between 0 and len(list_actions)
        selected_action = -1
        while selected_action < 0 or selected_action >= len(list_actions):
            print("Select the action to be played: ")
            selected_action = int(input())

            if selected_action < 0 or selected_action >= len(list_actions):
                print("Ups! the action must be between 0 and " + str(len(list_actions) - 1))

        return list_actions[selected_action]

    def __str__(self):
        return "HumanPlayer"
