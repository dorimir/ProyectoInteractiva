from Game.ForwardModel import ForwardModel
from Players.Player import Player


class SimpleRulePlayer(Player):
    def __init__(self):
        super().__init__()
        self.previous_position = None

    def reset(self):
        self.previous_position = None

    def think(self, observation, budget):
        # TO DO
        # Get the list of all possible actions
        list_actions = observation.get_list_actions()

        # Select the first action that produces a valid move.
        # Discard actions that fall into a hole,
        # move backwards, or do not move at all.
        fm = ForwardModel()

        for action in list_actions:
            obs = observation.clone()

            current_position = obs.get_position()
            fm.test(obs, action)
            # get score de cada accion

            new_position = obs.get_position()

            if obs.reached_goal() or \
                    (not obs.is_in_a_hole() and
                     new_position != current_position and
                     self.previous_position != new_position):
                self.previous_position = current_position
                return action

        return None

    def __str__(self):
        return "SimpleRulePlayer"
