# Abstract class for players
class Player:
    def __init__(self):
        pass

    def think(self, observation, budget):
        pass

    def reset(self):
        pass
