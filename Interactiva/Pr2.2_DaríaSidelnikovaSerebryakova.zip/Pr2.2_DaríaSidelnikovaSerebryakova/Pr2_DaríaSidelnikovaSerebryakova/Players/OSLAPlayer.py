import math

from Game.ForwardModel import ForwardModel
from Heuristics.DistanceHeuristic import DistanceHeuristic
from Players.Player import Player


class OSLAPlayer(Player):
    def __init__(self):
        super().__init__()
        self.forward_model = ForwardModel()
        self.heuristic = DistanceHeuristic()
        self.previous_position = None

    def reset(self):
        self.previous_position = None

    def _find_goal(self, observation):
        maze = observation.maze
        for row in range(maze.number_rows):
            for column in range(maze.number_columns):
                if maze.is_goal(row, column):
                    return (row, column)
        return None

    def think(self, observation, budget):
        list_actions = observation.get_list_actions()
        best_action = None
        best_score = None
        current_position = observation.get_position()
        goal = self._find_goal(observation)

        for action in list_actions:
            next_observation = observation.clone()
            self.forward_model.test(next_observation, action)
            next_position = next_observation.get_position()

            if next_observation.reached_goal():
                self.previous_position = current_position
                return action

            if next_observation.is_in_a_hole() or \
                    next_position == current_position or \
                    next_position == self.previous_position:
                continue

            score = self.heuristic.get_score( # Llama la función del Distance Hueristics
                next_observation, next_position, goal
            )

            if best_score is None or score > best_score:
                best_score = score
                best_action = action

        if best_action is not None:
            self.previous_position = current_position
            return best_action

        return None

    def __str__(self):
        return "OSLAPlayer"