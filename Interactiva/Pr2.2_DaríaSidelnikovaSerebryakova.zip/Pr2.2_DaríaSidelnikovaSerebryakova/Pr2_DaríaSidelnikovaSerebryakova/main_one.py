from Game.Game import Game
from Mazes.MazeOriginal import MazeOriginal
from Players.OSLAPlayer import OSLAPlayer
# from Players.RandomPlayer import RandomPlayer
from Players.SimpleRulePlayer import SimpleRulePlayer


if __name__ == '__main__':
    budget = 1                  # Time, in seconds, that the players have to think
    max_iterations = 100
    verbose = True

    # player = RandomPlayer()
    # player = SimpleRulePlayer()
    player = OSLAPlayer()

    maze = MazeOriginal()
    # maze = MazeAlmagro()
    # maze = MazeFuster()
    # maze = MazeGarciaL()
    # maze = MazeGarciaS()
    # maze = MazeGomez()
    # maze = MazeGonzalez()
    # maze = MazeIzquierdo()
    # maze = MazeLopez()
    # maze = MazeMartinez()
    # maze = MazeMontoliu()
    # maze = MazeOriginal()
    # maze = MazeSanchez()
    # maze = MazeTrigueros()

    game = Game()
    game.run(maze, player, budget, max_iterations, verbose)


