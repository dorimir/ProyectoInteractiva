class ForwardModel:
    def __init__(self):
        pass

    def play(self, game_state, action):
        [row, column] = game_state.get_position()

        # If the cell to move in is into the maze and it is not a wall, update the game state
        if action.is_up() and game_state.is_into_maze(row - 1, column) and not game_state.is_wall(row - 1, column):
            game_state.set_position(row - 1, column)
        elif action.is_right() and game_state.is_into_maze(row, column + 1) and not game_state.is_wall(row, column + 1):
            game_state.set_position(row, column + 1)
        elif action.is_down() and game_state.is_into_maze(row + 1, column) and not game_state.is_wall(row + 1, column):
            game_state.set_position(row + 1, column)
        elif action.is_left() and game_state.is_into_maze(row, column - 1) and not game_state.is_wall(row, column - 1):
            game_state.set_position(row, column - 1)

        game_state.increment_iteration_number()

    def test(self, observation, action):
        [row, column] = observation.get_position()

        # If the cell to move in is into the maze and it is not a wall, update the observation
        if action.is_up() and observation.is_into_maze(row - 1, column) and not observation.is_wall(row - 1, column):
            observation.set_position(row - 1, column)
        elif action.is_right() and observation.is_into_maze(row, column + 1) and not observation.is_wall(row, column + 1):
            observation.set_position(row, column + 1)
        elif action.is_down() and observation.is_into_maze(row + 1, column) and not observation.is_wall(row + 1, column):
            observation.set_position(row + 1, column)
        elif action.is_left() and observation.is_into_maze(row, column - 1) and not observation.is_wall(row, column - 1):
            observation.set_position(row, column - 1)
