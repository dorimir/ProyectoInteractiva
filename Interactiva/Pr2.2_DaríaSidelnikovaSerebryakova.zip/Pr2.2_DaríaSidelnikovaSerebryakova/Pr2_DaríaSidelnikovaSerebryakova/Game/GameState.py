from Game.Observation import Observation


class GameState:
    def __init__(self):
        self.maze = None
        self.row = 0
        self.column = 0
        self.iteration_number = 0
        self.max_iterations = 50

    def reset(self, maze, max_iterations):
        start_position = maze.get_start_position()
        self.maze = maze.clone()
        self.row = start_position[0]
        self.column = start_position[1]
        self.iteration_number = 0
        self.max_iterations = max_iterations

    def get_iteration_number(self):
        return self.iteration_number

    def increment_iteration_number(self):
        self.iteration_number += 1

    def get_position(self):
        return [self.row, self.column]

    def set_position(self, row, column):
        self.row = row
        self.column = column

    # Returns True if the position is a terminal state (goal or hole). False Otherwise.
    def is_terminal(self):
        return self.maze.is_goal(self.row, self.column) or \
               self.maze.is_hole(self.row, self.column) or \
               self.iteration_number >= self.max_iterations

    # Returns True if the player has reached the goal cell. False Otherwise.
    def reached_goal(self):
        return self.maze.is_goal(self.row, self.column)

    # Returns True if the position is a wall. False Otherwise.
    def is_wall(self, row, column):
        return self.maze.is_wall(row, column)

    # Deep copy of the game state
    def clone(self):
        new_game_state = GameState()
        new_game_state.row = self.row
        new_game_state.column = self.column
        new_game_state.maze = self.maze.clone()
        new_game_state.iteration_number = self.iteration_number
        new_game_state.max_iterations = self.max_iterations
        return new_game_state

    # Return the observation. In this game, all parts of the game state are accessible.
    def get_observation(self):
        new_observation = Observation()
        new_observation.set(self)
        return new_observation

    # Returns True if the position is a valid cell in the maze. False Otherwise.
    def is_into_maze(self, row, column):
        return self.maze.is_into_maze(row, column)

    def __str__(self):
        s = "Position: [" + str(self.row) + ", " + str(self.column) + "]\n"
        s += str(self.maze)
        return s
