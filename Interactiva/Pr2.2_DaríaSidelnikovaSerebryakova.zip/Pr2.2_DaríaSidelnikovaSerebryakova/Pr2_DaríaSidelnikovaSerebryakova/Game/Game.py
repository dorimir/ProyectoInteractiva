from Game.ForwardModel import ForwardModel
from Game.GameState import GameState



class Game:
    def __init__(self):
        self.game_state = GameState()
        self.forward_model = ForwardModel()

    def run(self, maze, player, budget, max_iterations, verbose):
        self.game_state.reset(maze, max_iterations)

        while not self.game_state.is_terminal():
            if verbose:
                print("Iteration: " + str(self.game_state.get_iteration_number()))
            observation = self.game_state.get_observation()     # get the observation from the game state
            if verbose:
                observation.print_maze()
            action = player.think(observation, budget)          # player must select the action to be played
            if action is None:
                break
            else:
                if verbose:
                    print("Player select:" + str(action) + "\n")
                self.forward_model.play(self.game_state, action)    # play the action updating the game state

        if self.game_state.reached_goal():
            if verbose:
                print("Player reached the goal !!!")
            reached_goal = True
        else:
            if verbose:
                print("Ups!!! player could not find the exit")
            reached_goal = False

        return [reached_goal, self.game_state.get_iteration_number()]
