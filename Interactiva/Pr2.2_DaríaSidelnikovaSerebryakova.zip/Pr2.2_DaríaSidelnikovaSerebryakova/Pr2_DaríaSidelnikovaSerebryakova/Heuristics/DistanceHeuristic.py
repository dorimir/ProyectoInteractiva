from Heuristics.Heuristic import Heuristic

class DistanceHeuristic(Heuristic):
    def __init__(self):
        super().__init__()

    def get_score(self, observation, next_position, goal):
        if observation.is_in_a_hole():
            return -500
        elif observation.reached_goal():
            return 500
        else:
            score = 0

        if goal is not None:
            score -= abs(next_position[0] - goal[0]) + abs(next_position[1] - goal[1])
        return score
