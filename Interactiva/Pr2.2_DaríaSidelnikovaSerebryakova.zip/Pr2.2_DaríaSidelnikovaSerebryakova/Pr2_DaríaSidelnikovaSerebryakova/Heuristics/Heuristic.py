class Heuristic:
    def __init__(self):
        pass

    def get_score(self, observation):
        pass
